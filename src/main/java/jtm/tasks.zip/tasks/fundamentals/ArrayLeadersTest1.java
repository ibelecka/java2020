package jtm.tasks.fundamentals;

public class ArrayLeadersTest1 extends ArrayLeadersTest {
}
