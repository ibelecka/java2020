package jtm.tasks.fundamentals;

import java.util.Arrays;

public class ArrayLeaders {

    /*
        TODO
        Given an array/list [] of integers , Find all the LEADERS in the array.
        An element is leader if it is greater than The Sum all the elements to its right side.

        Array size is at least 3 .
        Array numbers Will be mixture of positives , negatives and zeros
        Repetition of numbers in the array could occur.
        Returned Array should store the leading numbers in the same order in the original array.
     */
    public static int[] arrayLeaders(int[] numbers) {
        return null;
    }
}
