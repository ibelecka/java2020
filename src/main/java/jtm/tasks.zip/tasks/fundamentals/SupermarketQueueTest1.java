package jtm.tasks.fundamentals;

public class SupermarketQueueTest1 extends SupermarketQueueTest {
}
