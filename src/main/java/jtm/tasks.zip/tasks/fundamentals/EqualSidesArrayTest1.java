package jtm.tasks.fundamentals;

public class EqualSidesArrayTest1 extends EqualSidesArrayTest {
}
