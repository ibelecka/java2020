package jtm.tasks.fundamentals;

public class DiceHistogramTest1 extends DiceHistogramTest {
}
