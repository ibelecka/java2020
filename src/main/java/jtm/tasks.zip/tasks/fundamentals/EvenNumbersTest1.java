package jtm.tasks.fundamentals;

public class EvenNumbersTest1 extends EvenNumbersTest {
}
