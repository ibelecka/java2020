package jtm.tasks.fundamentals;

public class JosephusSurvivorTest1 extends JosephusSurvivorTest {
}
