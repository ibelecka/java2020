package jtm.tasks.fundamentals;

public class MaxMultipleTest1 extends MaxMultipleTest {
}
