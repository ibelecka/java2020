package jtm.tasks.fundamentals;

public class TenMinWalkTest1 extends TenMinWalkTest {
}
