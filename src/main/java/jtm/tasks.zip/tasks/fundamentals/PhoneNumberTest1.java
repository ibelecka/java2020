package jtm.tasks.fundamentals;

public class PhoneNumberTest1 extends PhoneNumberTest {
}
